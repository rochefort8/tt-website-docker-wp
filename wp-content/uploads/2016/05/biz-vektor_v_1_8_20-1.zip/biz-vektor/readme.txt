
== Description ==
BizVektor theme will allow you to build a high-quality business web site.It is possible to change the color in the Theme Customizer, to switch to a completely different design.In addition, it is possible to increase the design by the plug-in.
Official site : http://sample.bizvektor.com ( Sorry, english version is under construction. )
Sample site : http://sample.bizvektor.com

=== Tags ===
white, red, blue, black, green, orange, purple, two-columns, right-sidebar, left-sidebar, one-columns, responsive, custom-background, custom-colors, custom-header, custom-menu, editor-style,theme-options


=== Features ===
Specializing in the business-friendly, Change design, Supports customizer, Responsive Layout, Many theme Setting options, Child page list template, Display contact information, Page Navigation, Breadcrumb Navigation, and more!


=== Widgets Areas ===
The Theme has 4 widget areas.
You can use these area to customize the content of your website.


== License ==
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License version 2, see file license.txt.
The exceptions to this license are as follows:
The script html5.js and css3-mediaqueries.js are licensed under MIT
Header Images are photo by theme author and are released under GPL license.


== Author ==
The theme built by Hidekazu Ishikawa (kurudrive) at Vektor,Inc.
You can contact me at inquiry form.
http://bizvektor.com/contact/


== Changelog ==
https://github.com/kurudrive/biz-vektor/commits/master